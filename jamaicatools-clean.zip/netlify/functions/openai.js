﻿exports.handler = async (event) => {
  try {
    const key = process.env.OPENAI_KEY;


    if (!key) {
      return {
        statusCode: 500,
        body: JSON.stringify({ text: "OPENAI_KEY is missing in Netlify." })
      };
    }


    const { prompt } = JSON.parse(event.body || "{}");


    if (!prompt) {
      return {
        statusCode: 400,
        body: JSON.stringify({ text: "Please enter a prompt first." })
      };
    }


    const response = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${key}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        model: "gpt-4o-mini",
        messages: [
          {
            role: "user",
            content: prompt
          }
        ]
      })
    });


    const data = await response.json();


    if (!response.ok) {
      return {
        statusCode: response.status,
        body: JSON.stringify({
          text: "OpenAI error: " + (data.error?.message || "Unknown API error")
        })
      };
    }


    return {
      statusCode: 200,
      body: JSON.stringify({
        text: data.choices[0].message.content
      })
    };


  } catch (error) {
    return {
      statusCode: 500,
      body: JSON.stringify({
        text: "Server error: " + error.message
      })
    };
  }
};