﻿exports.handler = async (event) => {
  try {
    const key = process.env.REMOVEBG_KEY;
    const { image } = JSON.parse(event.body || "{}");


    const form = new URLSearchParams();
    form.append("image_file_b64", image);
    form.append("size", "auto");


    const res = await fetch("https://api.remove.bg/v1.0/removebg", {
      method: "POST",
      headers: {
        "X-Api-Key": key,
        "Content-Type": "application/x-www-form-urlencoded"
      },
      body: form
    });


    if (!res.ok) {
      const errorText = await res.text();
      return {
        statusCode: res.status,
        body: errorText
      };
    }


    const buffer = await res.arrayBuffer();


    return {
      statusCode: 200,
      headers: {"Content-Type": "image/png"},
      body: Buffer.from(buffer).toString("base64"),
      isBase64Encoded: true
    };


  } catch (err) {
    return {
      statusCode: 500,
      body: err.message
    };
  }
};