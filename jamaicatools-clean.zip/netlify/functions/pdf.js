﻿exports.handler = async () => {
  try {
    const key = process.env.CLOUDCONVERT_KEY;


    if (!key) {
      return {
        statusCode: 500,
        body: JSON.stringify({ error: "CLOUDCONVERT_KEY is missing." })
      };
    }


    const r = await fetch("https://api.cloudconvert.com/v2/jobs", {
      method: "POST",
      headers: {
        Authorization: "Bearer " + key,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        tasks: {
          upload: {
            operation: "import/upload"
          },
          convert: {
            operation: "convert",
            input: "upload",
            output_format: "pdf"
          },
          export: {
            operation: "export/url",
            input: "convert"
          }
        }
      })
    });


    const d = await r.json();


    if (!r.ok) {
      return {
        statusCode: r.status,
        body: JSON.stringify({ error: d.message || d.error || d })
      };
    }


    return {
      statusCode: 200,
      body: JSON.stringify({
        jobId: d.data.id,
        tasks: d.data.tasks
      })
    };


  } catch (err) {
    return {
      statusCode: 500,
      body: JSON.stringify({ error: err.message })
    };
  }
};