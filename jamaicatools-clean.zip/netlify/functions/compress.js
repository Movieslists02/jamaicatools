﻿exports.handler = async (event) => {
  const API_KEY = process.env.TINYPNG_KEY;




  const res = await fetch("https://api.tinify.com/shrink", {
    method: "POST",
    headers: {
      "Authorization": "Basic " + Buffer.from("api:" + API_KEY).toString("base64")
    },
    body: event.body
  });




  const data = await res.json();




  return {
    statusCode: 200,
    body: JSON.stringify(data)
  };
};