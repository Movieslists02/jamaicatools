﻿exports.handler=async(e)=>{
const key=process.env.CLOUDCONVERT_KEY;
const job=e.queryStringParameters.job;
const r=await fetch("https://api.cloudconvert.com/v2/jobs/"+job,{
headers:{Authorization:"Bearer "+key}});
const d=await r.json();
let file=d.data.tasks.find(t=>t.operation==="export/url");
return {statusCode:200,body:JSON.stringify({
status:d.data.status,
download:file?.result?.files?.[0]?.url
})};
};