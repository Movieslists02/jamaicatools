﻿async function calc(){
 let amount = parseFloat(document.getElementById('a').value);


 let res = await fetch('/.netlify/functions/rates');
 let data = await res.json();


 document.getElementById('r').innerText =
   "JMD: " + (amount * data.JMD).toFixed(2);
}